## <img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Hi.gif" width="29px"> I'm Aris187 ID
<p align="center">
<img src="https://raw.githubusercontent.com/A187ID/AR15BOT/main/aris/A187.jpg" width="230" height="230"/>
</p>
<br>



<p align="center">
<a href="#"><img title="👾AR15BOT👾" src="https://img.shields.io/badge/AR15BOT-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center">
<a href="https://github.com/A187ID"><img title="Author" src="https://img.shields.io/badge/AUTHOR-ARIS187 ID-orange.svg?style=for-the-badge&logo=github"></a>
</p>
<p align="center">
<a href="https://www.codefactor.io/repository/github/A187ID/AR15BOT"><img title="Rating" src="https://www.codefactor.io/repository/github/A187ID/AR15BOT/badge/main"></a>
</p>
<p align="center">
<a href="https://github.com/A187ID/AR15BOT/followers"><img title="Followers" src="https://img.shields.io/github/followers/A187ID?color=blue&style=flat-square"></a>
<a href="https://github.com/A187ID/AR15BOT/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/A187ID/AR15BOT?color=red&style=flat-square"></a>
<a href="https://github.com/A187ID/AR15BOT/network/members"><img title="Forks" src="https://img.shields.io/github/forks/A187ID/AR15BOT?color=red&style=flat-square"></a>
<a href="https://github.com/A187ID/AR15BOT/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/A187ID/AR15BOT?label=Watchers&color=blue&style=flat-square"></a>
<a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2FA187ID%2FAR15BOT&count_bg=%2379C83D&title_bg=%23555555&icon=probot.svg&icon_color=%2300FF6D&title=hits&edge_flat=false"/></a>
</p>
<img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Developer.gif" alt="Mario Game" width="600" />
<div align="center">
<details>
 
</details>

### FITUR SEBAGAIAN AKU HAPUS,ADA YG GA TERIMA MAKASIH

## Clone this project

```bash
> git clone https://github.com/MhankBarBar/termux-wabot
```

## Install the dependencies:
Before running the below command, make sure you're in the project directory that
you've just cloned!!

```bash
> cd AR15BOT
> bash install.sh
```

### Usage
```bash
> npm start
```

## FEATURES  <img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Earth.gif" width="29px">

## Features

| Sticker Creator |                Feature           |
| :-----------: | :--------------------------------: |
|       ✅       | Send Photo with Caption          |
|       ✅       | Reply A Photo                    |
|       ✅       | Reply A Video or GIF             |
|       ✅       | Send Video or GIF with Caption   |
|       ✅       | Reply A Sticker ( sticker to image ) |

| Other  |                     Feature                     |
| :------------: | :---------------------------------------------: |
|       ✅        |   Get a random meme             |
|       ✅        |   Text to speech                |
|       ✅        |   Writing feature 				|
|       ✅        |   What Anime Is This 			|
|       ✅        |   Url2Img ( Screeenshot Web )   |
|       ✅        |   Simsimi		                |

| Group  |                     Feature               |
| :-----------: | :--------------------------------: |
|       ✅        |   Tagall/Mentionall member       |
|       ✅        |   Kick Member Group	             |
|       ✅        |   Add Member Group	             |
|       ✅        |   Get List Admins Group          |

| Owner Bot  |                     Feature           |
| :-----------: | :--------------------------------: |
|       ✅        |   Set Prefix                     |
|       ✅        |   Broadcast                      |
|       ✅        |   Clear All Chats                |

Ket: Aktiv 24 jam

## DONASI <img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/coin.gif" width="29px">
* [`Donasi 👾AR15BOT👾`](https://saweria.co/aris187id)


## SOSIAL MEDIA ADMIN <img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/powerup.gif" width="29px">

* [`Youtube Admin`](https://www.youtube.com/channel/UCGYLWtyT9IADYNUiK0uZiGg)
* [`Instagram Admin`](https://instagram.com/_sadboy.ig)
* [`WhatsApp Admin `](https://wa.me/+6285722553839)
## THANKS TO <img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Handshake.gif" width="60px">

* [`fdciabdul`](https://github.com/fdciabdul/termux-whatsapp-bot)

* [`ArugaZ`](https://github.com/ArugaZ/whatsapp-bot)
* [`MhankBarBar`](https://github.com/MhankBarBar/whatsapp-bot)
* [`Alfbot`](https://github.com/alfiansx/alfbot)
<img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Mario_Gameplay.gif" alt="Mario Game" width="600" />

